// script.js

document.addEventListener("DOMContentLoaded", () => {
    const chatInput = document.querySelector(".chat-input textarea");
    const chatbox = document.querySelector(".chatbox");
    const sendButton = document.querySelector(".chat-input span"); // Send button

    // Predefined responses
    const responses = {
        "hello": "Hi there! How can I help you today?",
        "hi":"Hi there! How can I help you today?",
        "how are you?": "I'm just a bot, but thanks for asking!",
        "what is harmonyhub?": "HarmonyHub is a mental health care platform designed to support you.",
        "bye": "Thank you for spending time with me today, Take care of yourself, and until we meet again, breathe deep, stay strong, and keep moving forward. 💜",
        "i want to overcome addiction": "yes ofc you can do it just follow what i say",
        "i m feeling lonely": "I'm really sorry you're feeling this way. Loneliness can be tough, especially when it feels like there’s no one around who understands what you’re going through. Sometimes we experience loneliness even when we’re surrounded by people, and that can feel isolating.What’s important right now is to acknowledge how you’re feeling without judging yourself for it.",
        "how to overcome loneliness": "Acknowledge and Understand Your Feelings. Reach Out to Loved Ones. Engage in Activities You Enjoy. Practice Mindfulness or Meditation. You can checkout mindfullness tips in our app. Limit Social Media Comparison. very important talk about it",
        "i got bullied ": "I'm really sorry to hear that, . Being bullied can be incredibly painful and leave lasting emotional effects. It’s important to acknowledge that what happened to you is not your fault. You didn’t deserve to be treated that way. When you’re bullied, it can make you feel small, powerless, or even question your self-worth. But I want you to know that you are strong, and the fact that you're opening up about this is a huge step toward healing.",
        "how do i move on from bullying": "Understand It Wasn't Your Fault. Rebuild Your Self-Worth.Bullying can make you doubt yourself, but try to focus on things you love about who you are—whether it's your talents, creativity, intelligence, or kindness. Surround Yourself with Support",
        "my friends doesnt love me": "I'm really sorry to hear that you're going through friendship troubles right now. I understand how painful and confusing it can feel when relationships with friends aren't going well. Friendships are supposed to be a source of joy, and when they don’t feel that way, it can hurt deeply. Understand that your value isn't tied to external validation. You are worthy of love, success, and happiness simply because you exist. Acknowledging your inherent worth is the foundation of self-love.",
        "i dont have friends": "I'm really sorry to hear that you're going through friendship troubles right now. I understand how painful and confusing it can feel when relationships with friends aren't going well. Friendships are supposed to be a source of joy, and when they don’t feel that way, it can hurt deeply. Understand that your value isn't tied to external validation. You are worthy of love, success, and happiness simply because you exist. Acknowledging your inherent worth is the foundation of self-love.Give it Time and Space.Focus on Self-Care.Set Healthy Boundaries",
        "i m stressed about studies":"It’s completely normal to feel stressed about studies, especially when there are multiple responsibilities and high expectations involved. Here are some tips to help manage that stress:Break Down Your Tasks.Create a Study Schedule.Prioritize What’s Most Important.Practice Mindfulness or Deep Breathing. Don’t Hesitate to Ask for Help. Take Care of Your Physical Health",
        "stress":"It’s completely normal to feel stressed about studies, especially when there are multiple responsibilities and high expectations involved. Here are some tips to help manage that stress:Break Down Your Tasks.Create a Study Schedule.Prioritize What’s Most Important.Practice Mindfulness or Deep Breathing. Don’t Hesitate to Ask for Help. Take Care of Your Physical Health",
        "i have anxiety":"I'm really  sorry you're feeling this way, . Anxiety can be overwhelming, Here are some ways to manage it that might help you feel better.      1) Ground Yourself: This helps bring your mind back to the present moment.      2) Mindfulness Practice: If you'd like to talk more or focus on something that helps you relax, I'm here for you. How are you feeling right now?",
        "anxiety": "I'm really  sorry you're feeling this way, . Anxiety can be overwhelming, Here are some ways to manage it that might help you feel better.      1) Ground Yourself: This helps bring your mind back to the present moment.      2) Mindfulness Practice: If you'd like to talk more or focus on something that helps you relax, I'm here for you. How are you feeling right now?",
        "i have post-traumatic stress disorder ": "1. Grounding Techniques, 2. 😮‍💨Deep Breathing & Relaxation, 3. Support from a Trusted Person",
        "(PTSD)": "1. Grounding Techniques, 2. Deep Breathing & Relaxation, 3. Support from a Trusted Person",
        "why i am not anyone's favourite": " Hey! Cherished,  I hear you, and it’s okay to feel this way sometimes. But let me remind you: 🌟 You are special in your own way 💖. Being someone’s favorite doesn’t define your worth 🌷. You have so much to offer and you’re amazing just as you are ✨, You are unique, strong, and important 🦋. Don’t let this thought dim your light 🌞! Keep shining ✨, and remember: you’re enough just as you are",
        "why i don't feel confident": " Oh! Dearest, When you start doubting yourself, focus on the things you’ve already achieved 🎯 and remind yourself that growth takes time 🌱. Confidence isn’t about being perfect 💯—it’s about trusting yourself through the ups and downs 🌈.Keep going, you’ve got this! 🌻😊",
        "i am always an average": " Hey! Sweetie, being average is perfectly okay! 🌼 Everyone has their unique strengths and qualities ✨. Average doesn’t mean you’re not special 🌟; it just means you have room to grow and explore! 🌱Remember, many amazing people started from being average and worked hard to achieve their goals 🏆. It’s all about progress, not perfection 💪",
        "i am not good at anything": " Hey Precious!, it’s okay to feel that way sometimes 🌧️, but remember, everyone has something special about them! 🌟 You may not see it right now, but you have skills and qualities that make you unique 💖.Instead of focusing on what you think you're not good at, try exploring new interests or hobbies 🎨📚. Growth comes from trying new things, and it’s okay to be a beginner! 🌱",
        "i am not anyone's favourite": " Hey! Cherished,  I hear you, and it’s okay to feel this way sometimes. But let me remind you: 🌟 You are special in your own way 💖. Being someone’s favorite doesn’t define your worth 🌷. You have so much to offer and you’re amazing just as you are ✨, You are unique, strong, and important 🦋. Don’t let this thought dim your light 🌞! Keep shining ✨, and remember: you’re enough just as you are"
        
    };

    // Function to create a chat message
    function createChatMessage(message, type) {
        const chatMessage = document.createElement("li");
        chatMessage.classList.add("chat", type);
        chatMessage.innerHTML = type === "incoming" 
            ? `<span class="material-symbols-outlined">smart_toy</span><p>${message}</p>` 
            : `<p>${message}</p>`;
        chatbox.appendChild(chatMessage);
        chatbox.scrollTop = chatbox.scrollHeight; // Scroll to the bottom
    }

    // Event listener for sending a message
    sendButton.addEventListener("click", () => {
        const userMessage = chatInput.value.trim().toLowerCase(); // Get user input

        if (userMessage) {
            createChatMessage(userMessage, "outgoing"); // Show user message

            // Check if there's a predefined response
            const botResponse = responses[userMessage] || "I'm sorry, I don't understand that.";
            createChatMessage(botResponse, "incoming"); // Show bot response

            chatInput.value = ""; // Clear input field
        }
    });

    // Allow sending message by pressing Enter
    chatInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            sendButton.click(); // Trigger the send button click
        }
    });
});
