// YouTube API Key
const apiKey = 'AIzaSyBO5CqZ6A4FWzWd1DCvJ_rcvWePxXLuDIA';

// NewsAPI Key
const newsApiKey = '597b9912580f47b0b61c5dc6733710b3';

// Search button click event
document.getElementById('search-button').addEventListener('click', () => {
    const query = document.getElementById('search-query').value;
    fetchYouTubeVideos(query);
    fetchRelatedArticles(query);
});

// Function to fetch YouTube videos
function fetchYouTubeVideos(query) {
    const apiUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${query}&type=video&maxResults=10&key=${apiKey}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const videoContainer = document.getElementById('video-results');
            videoContainer.innerHTML = '';  // Clear previous results
            data.items.forEach(video => {
                const videoId = video.id.videoId;
                const videoTitle = video.snippet.title;
                const videoThumbnail = video.snippet.thumbnails.medium.url;
                const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

                // Create a new div for each video
                const videoElement = document.createElement('div');
                videoElement.classList.add('video-item');
                videoElement.innerHTML = `
                    <a href="${videoUrl}" target="_blank">
                        <img src="${videoThumbnail}" alt="${videoTitle}" class="thumbnail" />
                    </a>
                    <div class="video-title">
                        <a href="${videoUrl}" target="_blank">${videoTitle}</a>
                    </div>
                `;
                videoContainer.appendChild(videoElement);

                // Apply styles using JavaScript (remove underline, set colors)
                const videoLink = videoElement.querySelector('.video-title a');
                videoLink.style.textDecoration = 'none';  // Removes underline
                videoLink.style.color = '#6b2fb9';        // Matches theme
                videoLink.addEventListener('mouseover', () => {
                    videoLink.style.color = '#f57c00';   // Change color on hover
                });
                videoLink.addEventListener('mouseout', () => {
                    videoLink.style.color = '#6b2fb9';   // Revert color after hover
                });
            });
        })
        .catch(error => console.error('Error fetching videos:', error));
}

